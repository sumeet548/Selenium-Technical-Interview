﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Firefox;
using OpenQA.Selenium.Support.UI;
using OpenQA.Selenium.Support;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;
using System.Threading;

namespace WebDriverFoxInterview
{
    public class WebSiteRegistration
    {
        public string FirstName = "";
        public string LastName = "";
        public string EmailAddress = "";
        public string Password = "";
        public string Gender = "";
        public string birthDate = ""; // in "MM/DD/YYYY"
    }

    public class ShowDetails
    {
        public bool IsPresentInFoxTab;
        public bool IsPresentInFXTab;
        public bool IsPresentInNGTab;
        public bool IsPresentInFOXSportsTab;
        public bool IsPresentInAllShowTab;
    }

    public class LoginInformation
    {
        public string UserName = "";
        public string Password = "";

    }

    class Program
    {

        static void Main(string[] args)
        {
            //In the batch file; these three elements can be read from a configuration
            string FireFoxDriverPath = @"C:\Sumeet\Selenium\WebDriverFoxInterview\geckodriver-v0.20.1-win64";
            string BrowserType = "firefox";
            string ExcelPath = string.Format(@"C:\Sumeet\Selenium\WebDriverFoxInterview\Excel\FOXShows{0}.xls", DateTime.Now.ToString("d MM yy"));

            #region SignUp is commented. Can be uncommented before execution
            /*//SignUp and Login
            WebSiteRegistration registrationDetails = new WebSiteRegistration();
            registrationDetails.FirstName = "Abc";
            //Module 1 : Register Fox Website;
            RegisterFoxWebSite(registrationDetails, FireFoxDriverPath, BrowserType);
            */
            #endregion

            // Module 2 : Login and Serch and Compare
            LoginInformation login = new LoginInformation();
            login.UserName = "sumeet.khanna2003@gmail.com";
            login.Password = "Ameyaa";
            LoginSearchAndCompareShows(BrowserType, FireFoxDriverPath, login, ExcelPath);


        }

        public static bool RegisterFoxWebSite(WebSiteRegistration RegisDetails, string DriverPath, string BrowserType)
        {
            bool IsLoginSuccessfullyCreated = false;
            IWebDriver webDriver = null;
            string dobXPath = @"//div[@class='Account_signupBirthdayGenderContainer_1n0m8']//div[@class='Account_signupColumnSplit_YtgPc']//input[@type='text']";


            try
            {
                // Check Browser Type
                webDriver = CheckBrowserAndReturnHandler(BrowserType, DriverPath);

                //Step 1 : Browse Main Site
                BrowseMainWebSite(webDriver);

                //Step 2 : Identify the SignUp-SignIn Element
                webDriver.FindElement(By.Id("path - 1")).Click();

                //Wait for 10 Sec
                AddTimeWait(webDriver, 10);

                // Step 3 : Click Sign Up
                webDriver.FindElement(By.ClassName("Account_signUp_3SpTs")).Click();

                //Wait for 10 Sec
                AddTimeWait(webDriver, 10);

                webDriver.FindElement(By.Name("signupFirstName")).SendKeys(RegisDetails.FirstName);
                webDriver.FindElement(By.Name("signupLastName")).SendKeys(RegisDetails.LastName);
                webDriver.FindElement(By.Name("signupEmail")).SendKeys(RegisDetails.EmailAddress);
                webDriver.FindElement(By.Name("signupPassword")).SendKeys(RegisDetails.Password);

                webDriver.FindElement(By.LinkText("Gender")).Click();
                AddTimeWait(webDriver, 10);
                webDriver.FindElement(By.LinkText("Prefer not to say")).Click();
                webDriver.FindElement(By.XPath(dobXPath)).SendKeys(RegisDetails.birthDate);

                //Hit SignUp
                webDriver.FindElement(By.ClassName("Account_signupButtonDesktop_1PCXs")).Click();
                IsLoginSuccessfullyCreated = true;
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured in SignUp {0} ", ex.Message);
            }

            return IsLoginSuccessfullyCreated;
        }

        public static IWebDriver CheckBrowserAndReturnHandler(string BrowserType, string DriverPath)
        {
            IWebDriver webDriver = null;

            // Check Browser Type
            if (BrowserType == "chrome")
            {
                webDriver = new ChromeDriver(DriverPath);
            }
            else if (BrowserType == "firefox")
            {
                webDriver = new FirefoxDriver(DriverPath);
            }
            else
            {
                Console.WriteLine("supply proper browser name");
            }

            return webDriver;

        }

        public static bool LoginSearchAndCompareShows(string BrowserType, string DriverPath, LoginInformation LoginDetails, string ExcelPath)
        {
            bool showSearchSuccess = false;
            IWebDriver webDriver = null;
            

            webDriver = CheckBrowserAndReturnHandler(BrowserType, DriverPath);

            //Step 1 : Browse Main Site
            BrowseMainWebSite(webDriver);

            //Login : Identify the SignUp-SignIn Element
            webDriver.FindElement(By.Id("path-1")).Click();
            
            webDriver.FindElement(By.ClassName("Account_signIn_Q0B7n")).Click();
            webDriver.FindElement(By.Name("signinEmail")).SendKeys(LoginDetails.UserName);
            webDriver.FindElement(By.Name("signinPassword")).SendKeys(LoginDetails.Password);
            webDriver.FindElement(By.ClassName("Account_signinButtonDesktop_2SO1g")).Click();

            
            int milliseconds = 10000;
            Thread.Sleep(milliseconds);

            
            // Step 1 : Click on the Show Tab
            string showTabXPath = @"//div[@class='Header_navLinks_1WBD8']/a[@href='/shows/']";
            webDriver.FindElement(By.XPath(showTabXPath)).Click();
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);
            // chromeDriver.FindElement(By.CssSelector("[class*='PageHeaderBrowse_tab_19aN7 PageHeaderBrowseAltHeader_tab_2Lzol PageHeaderBrowse_active_1-pOT']")); 

            #region OldFOX
            /*// Step 2 : Click on the FOX Tab
            webDriver.FindElement(By.CssSelector("[class='PageHeaderBrowse_tab_19aN7 PageHeaderBrowseAltHeader_tab_2Lzol PageHeaderBrowse_active_1-pOT']")).Click(); 
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(10);

            // Step 3 : Read all show names from FOX tab 
            string allFOXShowsXPath = @"//div[@class='MovieTile_titleText_1Q4bx']";
            webDriver.FindElements(By.XPath(allFOXShowsXPath));*/
            #endregion

            List<string> allShowsOnFox = SearchFOXTab(webDriver);
            List<string> allShowsOnFXTab = SearchFXTab(webDriver);
            List<string> allShowsOnNGTab = SearchNGTab(webDriver);
            List<string> allShowsOnFoxSportsTab = SearchFoxSportsTab(webDriver);
            List<string> allShowsOnAllShowsTab = SearchAllShowsTab(webDriver);


            //Step 4 : Export Shows To Excel

            List<string> ShowsToCheck = new List<string>();
            ShowsToCheck.Add("24 Hours To Hell & Back");
            ShowsToCheck.Add("So You Think You Can Dance");
            ShowsToCheck.Add("Meghan Markle: An American Princess");
            ShowsToCheck.Add("Hypnotize Me");
            ShowsToCheck.Add("Ghosted");


            //=
            //{
            //    { "24 Hours To Hell & Back","" },
            //    { "So You Think You Can Dance", "" }, 
            //    { "Meghan Markle: An American Princess", "" }, 
            //    { "Hypnotize Me", "" },
            //};


            List<string> ShowNames = new List<string>();
            

            foreach (string showName in allShowsOnFox)
            {
                if (ShowsToCheck.Contains(showName, StringComparer.OrdinalIgnoreCase))
                {
                    ShowNames.Add(showName);
                }
            }

            string[,] ShowsToBeSearched = new string[ShowNames.Count, 2];

            int i = 0;

            foreach (string FoundshowName in ShowNames)
            {

                ShowsToBeSearched.SetValue(FoundshowName, i, 0);

                if (allShowsOnFXTab.Contains(FoundshowName, StringComparer.OrdinalIgnoreCase) ||
                    allShowsOnNGTab.Contains(FoundshowName, StringComparer.OrdinalIgnoreCase) ||
                    allShowsOnFoxSportsTab.Contains(FoundshowName, StringComparer.OrdinalIgnoreCase) ||
                    allShowsOnAllShowsTab.Contains(FoundshowName, StringComparer.OrdinalIgnoreCase)
                )
                {
                    ShowsToBeSearched.SetValue("Duplicate Record", i, 1);
                }
                else
                {
                    ShowsToBeSearched.SetValue("", i, 1);
                }
                i++;
            }


            //Create Excel File
            //CreateExcelFile(ShowNames, ExcelPath);
            webDriver.Close();
            

            CreateExcelFileFromArray(ShowsToBeSearched, ExcelPath);

            return showSearchSuccess;
        }

        public static void AddTimeWait(IWebDriver webDriver, int TimeInSec)
        {
            webDriver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(5);
        }

        public static List<string> SearchShowNames(IWebDriver webDriverHandle)
        {
            string allShowsXPath = @"//div[@class='MovieTile_titleText_1Q4bx']";
            IReadOnlyCollection<IWebElement> allShows = webDriverHandle.FindElements(By.XPath(allShowsXPath));

            List<string> ShowNames = new List<string>();
            foreach (IWebElement showName in allShows)
            {

                ShowNames.Add(showName.Text);

            }

            return ShowNames;
        } 

        public static List<string> SearchFOXTab(IWebDriver webDriverHandle)
        {
            webDriverHandle.FindElement(By.LinkText("FOX")).Click();
            return SearchShowNames(webDriverHandle);
        }

        private static List<string> SearchFXTab(IWebDriver webDriverHandle)
        {
            webDriverHandle.FindElement(By.LinkText("FX")).Click();
            return SearchShowNames(webDriverHandle);
        }

        private static List<string> SearchNGTab(IWebDriver webDriverHandle)
        {
            webDriverHandle.FindElement(By.LinkText("National Geographic")).Click();
            return SearchShowNames(webDriverHandle);
        }

        private static List<string> SearchFoxSportsTab(IWebDriver webDriverHandle)
        {
            webDriverHandle.FindElement(By.LinkText("FOX Sports")).Click();
            return SearchShowNames(webDriverHandle);
        }

        private static List<string> SearchAllShowsTab(IWebDriver webDriverHandle)
        {
            webDriverHandle.FindElement(By.LinkText("All Shows")).Click();
            return SearchShowNames(webDriverHandle);
        }


        public static void BrowseMainWebSite(IWebDriver webDriver)
        {
            webDriver.Url = @"https://fox.com";
            
            //Wait for 10 seconds to load the page properly'
            AddTimeWait(webDriver, 10);
            
            // Maximize the window 
            webDriver.Manage().Window.Maximize();
            
            //Wait for 10 seconds to load the page properly'
            AddTimeWait(webDriver, 10);
            
        }


        public static bool CreateExcelFile(List<string> showNames, string ExcelFileName)
        {
           
            bool ExcelCreatedSuccessfully = false;

            //If old File Exists; Delete the file
            if (File.Exists(ExcelFileName))
            {
                File.Delete(ExcelFileName);
            }


            try
            {

                Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();

                if (ExcelApp is null)
                {
                    return ExcelCreatedSuccessfully;
                }

                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                xlWorkBook = ExcelApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "Show";
                int j = 2;
                foreach (string showName in showNames)
                {
                    xlWorkSheet.Cells[j, 1] = showName;
                    j++;
                }


                //"d:\\csharp-Excel.xls"
                xlWorkBook.SaveAs(
                    ExcelFileName, 
                    Excel.XlFileFormat.xlWorkbookNormal, 
                    misValue, misValue, misValue, misValue, 
                    Excel.XlSaveAsAccessMode.xlExclusive, 
                    misValue, misValue, misValue, misValue, misValue
                    );
                xlWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(ExcelApp);

                ExcelCreatedSuccessfully = true;
                // MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured {0}", ex.ToString());    
            }
            return ExcelCreatedSuccessfully;
        }

        public static bool CreateExcelFileFromArray(string[,] showNames, string ExcelFileName)
        {

            bool ExcelCreatedSuccessfully = false;

            //If old File Exists; Delete the file
            if (File.Exists(ExcelFileName))
            {
                File.Delete(ExcelFileName);
            }


            try
            {

                Microsoft.Office.Interop.Excel.Application ExcelApp = new Microsoft.Office.Interop.Excel.Application();

                if (ExcelApp is null)
                {
                    return ExcelCreatedSuccessfully;
                }

                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet;
                object misValue = System.Reflection.Missing.Value;

                xlWorkBook = ExcelApp.Workbooks.Add(misValue);
                xlWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)xlWorkBook.Worksheets.get_Item(1);

                xlWorkSheet.Cells[1, 1] = "Show";
                int j = 2;
                
                for (int row = 0; row < showNames.GetLength(0); row++)
                {
                    for (int col = 0; col < showNames.GetLength(1); col++)
                    {
                        if (!string.IsNullOrEmpty(showNames[row, col]))
                        {
                            xlWorkSheet.Cells[j, col + 1] = showNames[row, col];
                        }
                    }
                    j++;
                }

                //for (int i = 0; i <= showNames.Length; i++)
                //{
                //    if (!string.IsNullOrEmpty(showNames[ArrayRowCounter, ArrayRowCounter]))
                //    {
                //        xlWorkSheet.Cells[j, 1] = showNames[ArrayRowCounter, ArrayRowCounter];
                //        xlWorkSheet.Cells[j, 2] = showNames[ArrayRowCounter, 1];
                //        j++;
                        
                //    }
                //    ArrayRowCounter++;
                //}

                //foreach (string showName in showNames)
                //{
                //    xlWorkSheet.Cells[j, 1] = showName;
                //    j++;
                //}


                //"d:\\csharp-Excel.xls"
                xlWorkBook.SaveAs(
                    ExcelFileName,
                    Excel.XlFileFormat.xlWorkbookNormal,
                    misValue, misValue, misValue, misValue,
                    Excel.XlSaveAsAccessMode.xlExclusive,
                    misValue, misValue, misValue, misValue, misValue
                    );
                xlWorkBook.Close(true, misValue, misValue);
                ExcelApp.Quit();

                Marshal.ReleaseComObject(xlWorkSheet);
                Marshal.ReleaseComObject(xlWorkBook);
                Marshal.ReleaseComObject(ExcelApp);

                ExcelCreatedSuccessfully = true;
                // MessageBox.Show("Excel file created , you can find the file d:\\csharp-Excel.xls");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error Occured {0}", ex.ToString());
            }
            return ExcelCreatedSuccessfully;
        }

    }
}
